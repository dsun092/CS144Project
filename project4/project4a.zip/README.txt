Completed:

A.2 successfully outputs the itemID and name based on search query onto a HTML formatted table. The html is generated in the servlet section and does not make use of any JSP page. 

A.3 successfully parsed through XML returned from getXMlFromItemID and outputted the information into html page. 
TODO: Need to pass the XML parsed information into a JSP page, the specs does not allow us to output html from servlet. Also need to figure out how to obtain necessary multiple attributed information such as Categories and Bids.

A.4 Not done yet. Add simple navigational links. Should not take more than 20 minutes.

PARTNERS:

Zhongtai Sun: 903909635
Kevin Chanyoung Kim: 